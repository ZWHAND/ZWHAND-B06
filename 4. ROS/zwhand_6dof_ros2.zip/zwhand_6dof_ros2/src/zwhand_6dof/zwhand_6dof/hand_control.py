import rclpy
from rclpy.node import Node
from .modbus_control_api import hand_serial
    
from interface.srv import(
    CalibrationAllHand,
    # CalibrationSteppingMotors,
    CalibrationSingleMotor,
    ControlAllHand,ControlSingleMotor,
    ControlAllhandIncrement,ControlSingleMotorIncrement,

    SetID,
    SetBaudrate,

    SetSpeedAllHand,SetSpeedSingleMotor,
    SetCurrentAllHand,SetCurrentSingleMotor,


    RestoreFactorySettings,
    ClearError,
    StopEmergency,
    SaveConfiguration,

    GetHallError,
    GetDeviceVoltage,


    GetInitializationSignal,
    GetBootloaderVersion,GetHardwareVersion,GetSoftwareVersion,

    GetFullScalePosition,
    GetMotorRpm,
    GetMotorCurrent,
    GetPhaseLossFault,
    GetCurrentSampleError,

    GetRealtimeAngle,
    GetRealTimeMotorStall
)

from interface.msg import(
    RealtimeAngle,
    RealtimeMotorStall
)


class HandControlNode(Node):
    def __init__(self):
        super().__init__('hand_control_node')
        self.port = self.declare_parameter('port', '/dev/ttyUSB0').value
        self.baudrate = self.declare_parameter('baud', 115200).value
        self.hand_id = self.declare_parameter('hand_id',1).value
        self.hand = hand_serial(self, self.port, self.baudrate,self.hand_id)
        # self.hand = hand_serial(self.port, self.baudrate)

        

        
        self.angle_has_subscribers = False
        self.stall_has_subscribers = False


        self.calibration_all_hand_service = self.create_service(
            CalibrationAllHand,
            'zwhand_6dof/calibration_all_hand',
            self.hand.calibrationAllHandCallback
        )
        # self.calibration_stepping_motors = self.create_service(
        #     CalibrationSteppingMotors,
        #     'zwhand_6dof/calibration_stepping_motors',
        #     self.hand.calibrationSteppingMotorsCallback
        # )
        self.calibration_single_motor = self.create_service(
            CalibrationSingleMotor,
            'zwhand_6dof/calibration_single_motor',
            self.hand.calibrationSingleMotorCallback
        )


        self.control_all_hand_service = self.create_service(
            ControlAllHand,
            'zwhand_6dof/control_all_hand',
            self.hand.controlAllHandCallback
        )
        self.control_single_motor_service = self.create_service(
            ControlSingleMotor,
            'zwhand_6dof/control_single_motor',
            self.hand.controlSingleMotorCallback
        )


        self.control_all_hand_increment_service = self.create_service(
            ControlAllhandIncrement,
            'zwhand_6dof/control_all_hand_increment',
            self.hand.ControlAllhandIncrementCallback
        )
        self.control_single_motor_increment_service = self.create_service(
            ControlSingleMotorIncrement,
            'zwhand_6dof/control_single_motor_increment',
            self.hand.ControlSingleMotorIncrementCallback
        )





        self.set_ID_service = self.create_service(
            SetID,
            'zwhand_6dof/set_id',
            self.hand.SetIdCallback
        )


        self.set_baudrate_service = self.create_service(
            SetBaudrate,
            'zwhand_6dof/set_baudrate',
            self.hand.SetBaudrateCallback
        )

        self.set_speed_all_hand_service = self.create_service(
            SetSpeedAllHand,
            'zwhand_6dof/set_speed_all_hand',
            self.hand.SetSpeedAllHandCallback
        )
        self.set_speed_single_motor_service = self.create_service(
            SetSpeedSingleMotor,
            'zwhand_6dof/set_speed_single_motor',
            self.hand.SetSpeedSingleMotorCallback
        )


        self.set_current_single_motor_service = self.create_service(
            SetCurrentSingleMotor,
            'zwhand_6dof/set_current_single_motor',
            self.hand.SetCurrentSingleMotorCallback
        )        
        self.set_current_all_hand_service = self.create_service(
            SetCurrentAllHand,
            'zwhand_6dof/set_current_all_hand',
            self.hand.SetCurrentAllHandCallback
        )   


        self.clear_error_service = self.create_service(
            ClearError,
            'zwhand_6dof/clear_error',
            self.hand.ClearErrorCallback
        )
        self.restor_factory_settings_service = self.create_service(
            RestoreFactorySettings,
            'zwhand_6dof/restor_factory_settings',
            self.hand.RestoreFactorySettingsCallback
        )


        self.stop_emergency_service = self.create_service(
            StopEmergency,
            'zwhand_6dof/stop',
            self.hand.StopEmergencyCallback
        )
        self.save_configuration_service = self.create_service(
            SaveConfiguration,
            'zwhand_6dof/save_configuration',
            self.hand.SaveConfigurationCallback
        )

        self.get_initialization_success_signal_service = self.create_service(
            GetInitializationSignal,
            'zwhand_6dof/get_initialization_success_signal',
            self.hand.GetInitializationSignalCallback
        )

        self.get_bootLoader_version_service = self.create_service(
            GetBootloaderVersion,
            'zwhand_6dof/get_bootloader_version',
            self.hand.GetBootloaderVersionCallback
        )
        self.get_hardware_version_service = self.create_service(
            GetHardwareVersion,
            'zwhand_6dof/get_hardware_version',
            self.hand.GetHardwareVersionCallback
        )
        self.get_software_version_service = self.create_service(
            GetSoftwareVersion,
            'zwhand_6dof/get_software_version',
            self.hand.GetSoftwareVersionCallback
        )

        self.get_hall_error_service = self.create_service(
            GetHallError,
            'zwhand_6dof/get_hall_error',
            self.hand.GetHallErrorCallback
        )
        self.get_device_voltage_service = self.create_service(
            GetDeviceVoltage,
            'zwhand_6dof/get_device_voltage',
            self.hand.GetDeviceVoltageCallback
        )
        
        self.get_full_scale_position_service = self.create_service(
            GetFullScalePosition,
            'zwhand_6dof/get_full_scale_position',
            self.hand.GetFullScalePositionCallback
        )
        self.get_motor_rpm_service = self.create_service(
            GetMotorRpm,
            'zwhand_6dof/get_motor_rpm',
            self.hand.GetMotorRpmCallback
        )
        self.get_motor_current_service = self.create_service(
            GetMotorCurrent,
            'zwhand_6dof/get_motor_current',
            self.hand.GetMotorCurrentCallback
        )
        self.get_phase_loss_fault_service = self.create_service(
            GetPhaseLossFault,
            'zwhand_6dof/get_phase_loss_fault',
            self.hand.GetPhaseLossFaultCallback
        )
        self.get_current_sample_error_service = self.create_service(
            GetCurrentSampleError,
            'zwhand_6dof/get_current_sample_error',
            self.hand.GetCurrentSampleErrorCallback
        )

        self.get_realtime_angle_service = self.create_service(
            GetRealtimeAngle,
            'zwhand_6dof/get_realtime_angle',
            self.hand.GetRealtimeAngleCallback
        )
        self.get_realtime_motor_stall_service = self.create_service(
            GetRealTimeMotorStall,
            'zwhand_6dof/get_realtime_motor_stall',
            self.hand.GetRealTimeMotorStallCallback
        )


        # -------------------- topic communication --------------------
        self.realtime_angle_publisher  = self.create_publisher(
            RealtimeAngle,
            'zwhand_6dof/realtime_angle',
            10
        )
        self.realtime_motor_stall_publisher  = self.create_publisher(
            RealtimeMotorStall,
            'zwhand_6dof/realtime_motor_stall',
            10
        )

       # 创建定时器但不启动
        self.realtime_angle_publisher_timer = self.create_timer(
            0.1,  # 周期（秒）
            self.RealtimeAngleCallback  # 回调函数
        )
        self.realtime_angle_publisher_timer.cancel()  # 初始状态为取消
        
        self.realtime_motor_stall_publisher_timer = self.create_timer(
            0.35,  # 周期（秒）
            self.RealtimeMotorStallCallback  # 回调函数
        )
        self.realtime_motor_stall_publisher_timer.cancel()  # 初始状态为取消
        
        # 添加订阅者检查定时器
        self.subscriber_check_timer = self.create_timer(
            0.5,  # 每0.5秒检查一次订阅者状态
            self.check_subscribers
        )
        
        self.get_logger().info("Hand control node initialized successfully")

    def check_subscribers(self):
        """定期检查订阅者数量并控制发布器状态"""
        # 检查角度话题订阅者
        angle_sub_count = self.realtime_angle_publisher.get_subscription_count()
        if angle_sub_count > 0 and not self.angle_has_subscribers:
            self.angle_has_subscribers = True
            self.realtime_angle_publisher_timer.reset()  # 启动定时器
            self.get_logger().info(f"开始发布角度信息，当前订阅者数量: {angle_sub_count}")
        elif angle_sub_count == 0 and self.angle_has_subscribers:
            self.angle_has_subscribers = False
            self.realtime_angle_publisher_timer.cancel()  # 停止定时器
            self.get_logger().info("所有角度订阅者已退出，停止发布角度信息")
            
        # 检查电机堵转话题订阅者
        stall_sub_count = self.realtime_motor_stall_publisher.get_subscription_count()
        if stall_sub_count > 0 and not self.stall_has_subscribers:
            self.stall_has_subscribers = True
            self.realtime_motor_stall_publisher_timer.reset()  # 启动定时器
            self.get_logger().info(f"开始发布电机堵转信息，当前订阅者数量: {stall_sub_count}")
        elif stall_sub_count == 0 and self.stall_has_subscribers:
            self.stall_has_subscribers = False
            self.realtime_motor_stall_publisher_timer.cancel()  # 停止定时器
            self.get_logger().info("所有电机堵转信息订阅者已退出，停止发布")

    def RealtimeAngleCallback(self):
        """发布实时角度信息"""
        try:
            realtime_angles = self.hand.read_realtime_angles()

            if realtime_angles and len(realtime_angles) == 17:
                # 构造消息并发布
                msg = RealtimeAngle()
                msg.angles = realtime_angles  # 假设angles是17个整数的列表
                self.realtime_angle_publisher.publish(msg)
            else:
                self.get_logger().warn("Failed to read valid realtime angles")
        except Exception as e:
            self.get_logger().error(f"Error in realtime angle query: {str(e)}")

    def RealtimeMotorStallCallback(self):
        """发布电机堵转信息"""
        try:
            realtime_motor_stall = self.hand.read_realtime_motor_stall()

            if realtime_motor_stall and len(realtime_motor_stall) == 17:
                # 构造消息并发布
                msg = RealtimeMotorStall()
                msg.motor_stall = realtime_motor_stall
                self.realtime_motor_stall_publisher.publish(msg)
            else:
                self.get_logger().warn("Failed to read valid realtime motor stall")
        except Exception as e:
            self.get_logger().error(f"Error in realtime motor stall query: {str(e)}")



    def __del__(self):
        """Automatically called when nodes are destroyed"""
        self.hand.close()
        self.get_logger().info("The serial port has been closed through destructor")
def main(args=None):
    rclpy.init(args=args)
    hand_control_node = HandControlNode()
    rclpy.spin(hand_control_node)
    hand_control_node.destroy_node()
    rclpy.shutdown()
