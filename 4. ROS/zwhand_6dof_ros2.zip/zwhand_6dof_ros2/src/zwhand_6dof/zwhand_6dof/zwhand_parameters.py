hand_id = 1
baudrate = 115200

ALLOWED_BAUDRATES = {9600, 115200, 921600, 2000000}

# --------------      17registers       -----------------
# calibrationAllHandRegister = 0x6C
# calibrationSteppingMotorsRegister = 0x6B
# calibrationSingleMotorRegister = 0x5A
# controlAllHandRegister = 0x38
# controlSingleMotorRegister = 0x38
# ControlAllhandIncrementRegister = 0x49
# ControlSingleMotorIncrementRegister = 0x49
# SetIdRegister = 0x00
# SetBaudrateRegister = 0x01
# SetSpeedSingleMotorRegister = 0x05
# SetSpeedAllHandRegister = 0x05
# SetCurrentSingleMotorRegister = 0x05
# SetCurrentAllHandRegister = 0x05
# ClearErrorRegister = 0x02
# RestoreFactorySettingsRegister = 0x04
# SaveConfigurationRegister = 0x03
# StopEmergencyRegister = 0x27



# GetInitializationSignalRegister = 0x00
# GetBootloaderVersionRegister = 0x01
# GetHardwareVersionRegister = 0x02
# GetSoftwareVersionRegister = 0x03
# ReadRealtimeAngles = 0x30
# ReadRealtimeMotorStall = 0x1f




# --------------      6registers       -----------------


# --------------      holding registers       -----------------
SetIdRegister = 0x00
SetBaudrateRegister = 0x01
ClearErrorRegister = 0x02
SaveConfigurationRegister = 0x03
RestoreFactorySettingsRegister = 0x04
calibrationSingleMotorRegister = 0x05
controlAllHandRegister = 0x0B
controlSingleMotorRegister = 0x0B
ControlAllhandIncrementRegister = 0x11              
ControlSingleMotorIncrementRegister = 0x11
StopEmergencyRegister = 0x17
SetSpeedSingleMotorRegister = 0x1D
SetSpeedAllHandRegister = 0x1D
SetCurrentSingleMotorRegister = 0x23
SetCurrentAllHandRegister = 0x23
calibrationAllHandRegister = 0x29


# --------------      input registers       -----------------
GetInitializationSignalRegister = 0x00
GetBootloaderVersionRegister = 0x01
GetHardwareVersionRegister = 0x02
GetSoftwareVersionRegister = 0x03
GetHallErrorRegister = 0x04
GetVoltageAddressRegister = 0x0A
GetFullScalePositionRegister = 0x0B
ReadRealtimeMotorStall = 0x11
ReadRealtimeAngles = 0x17
GetMotorRpmRegister = 0x1D
GetMotorCurrentRegister = 0x23
GetPhaseLossFaultRegister = 0x29 
GetCurrentSampleErrorRegister = 0x2F
