# modbus_control_api.py
# 标准库导入
import logging
import os
import struct
import time
from typing import Tuple
from threading import Lock
import re
# 第三方库导入
import serial
from serial import SerialException
import serial.tools.list_ports

# ROS 2相关导入
import rclpy
from rclpy.node import Node
from ament_index_python.packages import get_package_share_directory

# 本地模块导入
from . import zwhand_parameters as zp
class hand_serial:
    def __init__(self, node: Node, port, baud, hand_id):
        self.node = node
        self.ser = None
        self.lock = Lock()  # 添加线程锁
        self.COMMAND_INTERVAL = 0.02  # 指令间隔时间（秒）
        self.last_command_time = 0  # 上次发送指令的时间
        
        

        self.port = port
        self.baudrate = baud
        self.hand_id = hand_id

        
        # port = node.get_parameter('port').value
        # baud = node.get_parameter('baud').value
        # hand_id = node.get_parameter('hand_id').value

        # if hand_id != zp.hand_id:
        #     zp_file_path = os.path.abspath(zp.__file__)
            
        #     self.node.get_logger().info(f"zp_file_path: {zp_file_path}")

        #     try:
        #         # 获取配置文件路径
        #         zp_file_path = os.path.abspath(zp.__file__)
        #         self.node.get_logger().info(f"配置文件路径: {zp_file_path}")

        #         # 检查文件是否存在
        #         if not os.path.exists(zp_file_path):
        #             self.node.get_logger().error(f"配置文件不存在: {zp_file_path}")
        #             return

        #         # 检查文件是否可写
        #         if not os.access(zp_file_path, os.W_OK):
        #             self.node.get_logger().error(f"没有文件写入权限: {zp_file_path}")
        #             return

        #         # 读取文件内容
        #         with open(zp_file_path, 'r', encoding='utf-8') as f:
        #             content = f.read()

        #         # 使用正则表达式匹配各种可能的格式 (hand_id=1, hand_id = 2, hand_id\t= 3等)
        #         pattern = r'(\s*hand_id\s*=)\s*.+'
        #         match = re.search(pattern, content)
                
        #         if not match:
        #             self.node.get_logger().error("在配置文件中未找到hand_id的定义")
        #             return

        #         self.node.get_logger().info(f"找到原始定义: {match.group(0)}")

        #         # 替换hand_id的值
        #         updated_content = re.sub(
        #             pattern,
        #             f'\g<1> {hand_id}',  # 保留原有格式，只替换值
        #             content
        #         )

        #         # 写入修改后的内容
        #         with open(zp_file_path, 'w', encoding='utf-8') as f:
        #             f.write(updated_content)

        #         # 验证修改结果
        #         with open(zp_file_path, 'r', encoding='utf-8') as f:
        #             new_content = f.read()
                
        #         new_match = re.search(pattern, new_content)
        #         if new_match and str(hand_id) in new_match.group(0):
        #             self.node.get_logger().info(f"成功将hand_id更新为: {hand_id}")
        #             # 注意：修改后需要重新加载模块才能生效，或重启程序
        #         else:
        #             self.node.get_logger().error("验证失败，hand_id未被正确更新")
        #     except Exception as e:
        #         self.node.get_logger().info(f"更新hand_id失败: {str(e)}")


        try:
            self.ser = serial.Serial(port, baud, timeout=0.1)
            if not self.ser.is_open:
                raise RuntimeError(f"Failed to open port: {port}")
                
            self.node.get_logger().info(f"Serial port opened: {port} @ {baud}bps")
            
            # 新增设备连接验证
            if not self._verify_device_connection():
                self._close_serial()
                raise RuntimeError("Failed to connect to the灵巧手 device. No response from device.")
            

        except SerialException as e:
            self.node.get_logger().fatal(f"SerialException: {str(e)}")
            self._close_serial()
            raise
            
        except Exception as e:
            self.node.get_logger().fatal(f"Unexpected error: {str(e)}")
            self._close_serial()
            raise
            
    # 添加设备验证方法
    def _verify_device_connection(self):
        """通过读取初始化信号寄存器验证设备是否连接"""
        self.node.get_logger().info("Verifying connection to 灵巧手 device...")
        
        try:
            # 等待串口稳定
            time.sleep(0.1)
            
        

            # 读取初始化信号寄存器（使用已有的读取方法）
            receive_data = self.read_multiple_data(
                self.hand_id, 
                zp.GetInitializationSignalRegister, 
                1, 
                0
            )

            self.node.get_logger().info(f"receive_data:{receive_data}")
            
            if receive_data and len(receive_data) >= 2:
                self.node.get_logger().info(
                    f"Successfully connected to 灵巧手 device. Initialization signal: {receive_data[1]}"
                )
                return True
            else:
                self.node.get_logger().error("Failed to get valid response from 灵巧手 device")
                return False
            
        except Exception as e:
            self.node.get_logger().error(f"Device verification failed: {str(e)}")
            return False

    # 添加缺失的_close_serial方法实现
    def _close_serial(self):
        """关闭串口连接"""
        if self.ser and self.ser.is_open:
            self.ser.close()
            self.node.get_logger().info(f"Serial port {self.port} closed")


    def wait_for_interval(self):
        """确保两次指令之间有足够的间隔"""
        current_time = time.time()
        elapsed = current_time - self.last_command_time
        
        if elapsed < self.COMMAND_INTERVAL:
            wait_time = self.COMMAND_INTERVAL - elapsed
            time.sleep(wait_time)
            
        self.last_command_time = current_time

    #  send data to a register
    def send_single_data(self, hand_id, address, data):
        self.node.get_logger().info(f"hand_id:{hand_id}")
        with self.lock:  # 添加线程锁
            self.wait_for_interval()  # 添加指令间隔
            
            if not self.ser or not self.ser.is_open:
                return 0
            else:
                bytes_value = data.to_bytes(2, byteorder='big', signed=True)
                step_list = list(bytes_value)
                
                single_motor_cmd = [hand_id, 0x10, 0x00, address, 0x00,
                                    0x01, 0x02, step_list[0], step_list[1]]
                
                cmd = self.modbus_crc(single_motor_cmd)
                
                try:
                    send_num = self.ser.write(cmd)
                    if send_num == len(single_motor_cmd):
                        receive_data = self.modbus_data_receive(single_motor_cmd[:6], 8)
                        return receive_data
                    else:
                        self.node.get_logger().error("Fail to send data!!")
                except Exception as e:
                    self.node.get_logger().error(f"Fail to send data: {e}")
            return 0

    #  send multiple datas to several continuous registers
    def send_multiple_data(self, hand_id, start_address, data):
        with self.lock:  # 添加线程锁
            self.wait_for_interval()  # 添加指令间隔
            
            if self.ser and self.ser.is_open:
                address_len = len(data)
                cmd_data = [0] * (7 + address_len*2)
                cmd_data[0] = hand_id
                cmd_data[1] = 0x10
                cmd_data[2] = 0x0
                cmd_data[3] = start_address
                cmd_data[4] = 0x0
                cmd_data[5] = address_len
                cmd_data[6] = address_len * 2
                
                for i in range(len(data)):
                    bytes_value = data[i].to_bytes(2, byteorder='big', signed=True)
                    step_list = list(bytes_value)
                    cmd_data[i * 2 + 7] = step_list[0]
                    cmd_data[i * 2 + 8] = step_list[1]

                cmd = self.modbus_crc(cmd_data)

                self.node.get_logger().info(f"cmd:{cmd}")

                try:
                    send_num = self.ser.write(cmd)
                    if send_num == len(cmd_data):
                        receive_data = self.modbus_data_receive(cmd_data[:6], 8)
                        return receive_data
                    else:
                        self.node.get_logger().error("发送失败")
                except Exception as e:
                    self.node.get_logger().error(f"发送失败: {e}")
            return 0

    #  read multiple datas from several registers
    def read_multiple_data(self, hand_id, start_address, address_len, register_type):
        with self.lock:  # 添加线程锁
            self.wait_for_interval()  # 添加指令间隔
            
            if self.ser and self.ser.is_open:
                cmd_data = [0] * 6
                cmd_data[0] = hand_id
                cmd_data[1] = 0x04
                # if register_type == 0:
                #     cmd_data[1] = 0x04
                cmd_data[2] = 0x0
                cmd_data[3] = start_address
                cmd_data[4] = 0x0
                cmd_data[5] = address_len

                cmd = self.modbus_crc(cmd_data)
                
                self.node.get_logger().info(f"send_cmd:{cmd}")


                self.ser.reset_input_buffer()
                send_num = self.ser.write(cmd)

                if send_num == len(cmd_data):
                    # 修正接收长度计算（关键修改）
                    receive_data_len = address_len * 2 + 5
                    receive_data = self.modbus_data_receive(
                        [hand_id, cmd_data[1], address_len * 2],
                        receive_data_len
                    )
                    
                    
                    self.node.get_logger().info(f"receive data:{receive_data}")

                    return receive_data

            return 0

    # --------------------------------------------------
    # Serial receive data
    # --------------------------------------------------
    def modbus_data_receive(self, detect_data, receive_data_len):
        start_time = time.time()
        while True:
            if time.time() - start_time > 2:  # 超时时间
                self.node.get_logger().error('超时数据接收失败')
                break
                
            try:
                if self.ser and self.ser.is_open:
                    available_num = self.ser.in_waiting
                else:
                    available_num = 0
            except Exception as e:
                available_num = 0

            if available_num >= receive_data_len:
                data = self.ser.read(available_num)
                data_list = list(data)
                
                for num in range(len(detect_data)):
                    if data_list[num] != detect_data[num]:
                        self.node.get_logger().error(f"Received data verification failed！！")
                        return 0
                        
                need_data = data_list[len(detect_data):-2]
                return need_data
        return 0

    # --------------------------------------------------
    # CRC16-Modbus
    # --------------------------------------------------
    @staticmethod
    def modbus_crc(data):
        crc = 0xFFFF
        for byte in data:
            crc ^= byte
            for _ in range(8):
                if crc & 0x0001:
                    crc >>= 1
                    crc ^= 0xA001
                else:
                    crc >>= 1
        crc_high = (crc >> 8) & 0xFF
        crc_low = crc & 0xFF
        data += [crc_low, crc_high]
        cmd = bytes(data)
        return cmd


    @staticmethod
    def validate_input(value):
        return 0 <= value <= 5
    
    # --------------------------------------------------
    # calibration callback functions
    # --------------------------------------------------

    def calibrationAllHandCallback(self, request, response):
        response.success = False
        receive_data = 0
        
        try:
            self.node.get_logger().info("Starting full hand calibration...")
            receive_data = self.send_single_data(self.hand_id, zp.calibrationAllHandRegister, 1)
            response.success = receive_data != 0
            self.node.get_logger().info(f"Full hand calibration success: {response.success}")
            
        except Exception as e:
            self.node.get_logger().error(f"Full hand calibration failed: {str(e)}")
            
        return response
    # def calibrationSteppingMotorsCallback(self, request, response):
    #     response.success = False
    #     receive_data = 0
        
    #     try:
    #         self.node.get_logger().info("Starting stepping motors calibration...")
    #         receive_data = self.send_single_data(self.hand_id, zp.calibrationSteppingMotorsRegister, 1)
            
    #         response.success = receive_data != 0
    #         self.node.get_logger().info(f"Stepping motors calibration success: {response.success}")
            
    #     except Exception as e:
    #         self.node.get_logger().error(f"Stepping motors calibration failed: {str(e)}")
            
    #     return response

    def calibrationSingleMotorCallback(self, request, response):
        response.success = False
        receive_data = 0
        
        try:
            motor_id = request.motor_id
            if not self.validate_input(motor_id):
                self.node.get_logger().error(f"Invalid motor_id: {motor_id} (must be 0-5)")
                return response
            register = zp.calibrationSingleMotorRegister + motor_id
            receive_data = self.send_single_data(self.hand_id, register, 1)
            
            response.success = receive_data != 0
            self.node.get_logger().info(f"Calibrate motor {motor_id} success: {response.success}")
            
        except Exception as e:
            self.node.get_logger().error(f"Failed to calibrate motor {motor_id}: {str(e)}")
        return response



    # --------------------------------------------------
    # control callback functions
    # --------------------------------------------------

    def controlAllHandCallback(self, request, response):
        response.success = False
        receive_data = 0
        try:
            if len(request.angles) != 6:
                self.node.get_logger().error(f"Invalid array length: {len(request.angles)} (expected 6)")
                return response
                
            for i, value in enumerate(request.angles):
                if not (0 <= value <= 1000):
                    self.node.get_logger().error(f"Angle {i}={value} out of range (0-1000)")
                    return response
            
            angles_list = [int(value) for value in request.angles]
            receive_data = self.send_multiple_data(self.hand_id, zp.controlAllHandRegister, angles_list)
            
            response.success = receive_data != 0
            self.node.get_logger().info(f"Control all hand success: {response.success}")
            
        except Exception as e:
            self.node.get_logger().error(f"Failed to control all hand: {str(e)}")
            
        return response
        
    def controlSingleMotorCallback(self, request, response):
        response.success = False
        receive_data = 0
        
        try:
            motor_id = request.motor_id
            if not self.validate_input(motor_id):
                self.node.get_logger().error(f"Invalid motor_id: {motor_id} (must be 0-5)")
                return response
                
            if not (0 <= request.angles <= 1000):
                self.node.get_logger().error(f"Angle {request.angles} out of range (0-1000)")
                return response
                
            register = zp.controlSingleMotorRegister + motor_id
            receive_data = self.send_single_data(self.hand_id, register, request.angles)
            
            response.success = receive_data != 0
            self.node.get_logger().info(f"Control motor {motor_id} to {request.angles} success: {response.success}")
        
        except Exception as e:
            self.node.get_logger().error(f"Failed to control motor {motor_id}: {str(e)}")
            
        return response
        

    def ControlAllhandIncrementCallback(self, request, response):
        response.success = False
        receive_data = 0
        
        if len(request.angles) != 6:
            self.node.get_logger().error(f"array length incorrect, requires 6 elements, now : {len(request.angles)}")
            return response
            
        # for i, value in enumerate(request.angles):
        #     if not (-1000 <= value <= 1000):
        #         self.node.get_logger().error(f"angles[{i}]'s value {value} out of range (-1000,1000)")
        #         return response
        
         # 关键修改：正确处理int16范围校验（-1000到1000）
        for i, value in enumerate(request.angles):
            # 将输入值视为有符号16位整数（处理负数）
            if value > 32767:  # 超过int16最大值，说明是负数补码
                value = value - 65536  # 转换为真实负数
            if not (-1000 <= value <= 1000):
                self.node.get_logger().error(f"angles[{i}]'s value {value} out of range (-1000,1000)")
                return response

        angles_list = [int(value) for value in request.angles]
        
        try:
            receive_data = self.send_multiple_data(self.hand_id, zp.ControlAllhandIncrementRegister, angles_list)
            response.success = receive_data != 0
            self.node.get_logger().info(f"Control All Hand (increment) success: {response.success}")

        except Exception as e:
            self.node.get_logger().error(f"Modbus通信失败: {str(e)}")
        
        return response
    
    def ControlSingleMotorIncrementCallback(self, request, response):
        receive_data = 0
        response.success = False

        if self.validate_input(request.motor_id):
            if -1000 <= request.angles <= 1000:
                register = zp.ControlSingleMotorIncrementRegister + request.motor_id
                receive_data = self.send_single_data(self.hand_id,register,request.angles)
                self.node.get_logger().info("Control Single Motor (increment)...")
                response.success = receive_data != 0
            else:
                self.node.get_logger().error(f"Input angle exceeds range(-1000,1000): {request.angles}")
        else:
            self.node.get_logger().error(f"Input motor_id exceeds range(0-5): {request.motor_id}")
        return response



    # --------------------------------------------------
    # Setter callback functions
    # --------------------------------------------------

    def SetIdCallback(self, request, response):
        response.success = False

        try:
            hand_id = request.hand_id
            self.node.get_logger().info(f"receive_hand_id{hand_id}")

            if not (1 <= hand_id <= 255):
                self.node.get_logger().error(f"Invalid hand_id: {hand_id} (must be 1-255)")
                return response

            if hand_id == self.hand_id:
                self.node.get_logger().info(f"Hand ID already set to {hand_id}")
                response.success = True
                return response
            

            result = self.send_single_data(self.hand_id, zp.SetIdRegister, hand_id)
            self.hand_id = hand_id
            if result == 0:
                raise RuntimeError("Failed to send ID setting command")

            self.node.get_logger().info(f"Temporary hand ID set to {hand_id} (will reset on power cycle)")
            response.success = True

        except Exception as e:
            self.node.get_logger().error(f"Failed to set temporary hand ID: {str(e)}")

        return response
    

    def SetBaudrateCallback(self, request, response):
        response.success = False

        try:
            baudrate = request.baudrate
            self.node.get_logger().info(f"receive_baudrate{baudrate}")

            if baudrate not in zp.ALLOWED_BAUDRATES:
                self.node.get_logger().error(f"Invalid baudrate: {baudrate} (must be {zp.ALLOWED_BAUDRATES})")
                return response

            # if baudrate == zp.baudrate:
            #     self.node.get_logger().info(f"Hand Baudrate already set to {baudrate}")
            #     response.success = True
            #     return response
            

            result = self.send_single_data(self.hand_id, zp.SetBaudrateRegister, baudrate)

            if result == 0:
                raise RuntimeError("Failed to send baudrate setting command")
            
            
            # zp.baudrate = baudrate
            self.ser.baudrate = baudrate
            # self.ser.reset_settings()

            self.node.get_logger().info(f"Temporary hand baudrate set to {baudrate} (will reset on power cycle)")
            self.node.get_logger().info(f"Please save configurations and restart terminal and restart zwhand(6dof)")

            response.success = True

        except Exception as e:
            self.node.get_logger().error(f"Failed to set temporary hand ID: {str(e)}")

        return response


    def SetSpeedSingleMotorCallback(self, request, response):
        response.success = False
        receive_data = 0
        
        try:
            motor_id = request.motor_id
            velocity = request.velocity
            if not self.validate_input(motor_id):
                self.node.get_logger().error(f"Invalid motor_id: {motor_id} (must be 0-5)")
                return response
                
            if not (0 <= velocity <= 100):
                self.node.get_logger().error(f"Velocity {velocity} out of range (0-100)")
                return response
                
            register = zp.SetSpeedSingleMotorRegister + motor_id
            receive_data = self.send_single_data(self.hand_id, register, velocity)

            response.success = receive_data != 0
            self.node.get_logger().info(f"Set motor {motor_id} velocity to {velocity} success: {response.success}")
        
        except Exception as e:
            self.node.get_logger().error(f"Failed to control motor {motor_id}: {str(e)}")
        return response
    
    def SetSpeedAllHandCallback(self, request, response):
        response.success = False
        receive_data = 0
        
        if len(request.velocity) != 6:
            self.node.get_logger().error(f"array length incorrect, requires 6 elements, now : {len(request.velocity)}")
            return response
            
        for i, value in enumerate(request.velocity):
            if not (0 <= value <= 100):
                self.node.get_logger().error(f"the value of velocity[{i}] : {value} is out of range (0, 100)")
                return response

        velocity_list = [int(value) for value in request.velocity]
        
        try:
            receive_data = self.send_multiple_data(self.hand_id, zp.SetSpeedAllHandRegister, velocity_list)
            response.success = receive_data != 0
            self.node.get_logger().info(f"Set All Hand velocities success: {response.success}")

        except Exception as e:
            self.node.get_logger().error(f"Modbus通信失败: {str(e)}")

        return response

    
    def SetCurrentSingleMotorCallback(self, request, response):
        response.success = False
        receive_data = 0
        
        try:
            motor_id = request.motor_id
            velocity = request.current
            if not self.validate_input(motor_id):
                self.node.get_logger().error(f"Invalid motor_id: {motor_id} (must be 0-5)")
                return response
                
            if not (0 <= velocity <= 100):
                self.node.get_logger().error(f"Velocity {velocity} out of range (0-100)")
                return response
                
            register = zp.SetCurrentSingleMotorRegister + motor_id
            receive_data = self.send_single_data(self.hand_id, register, velocity)

            response.success = receive_data != 0
            self.node.get_logger().info(f"Set motor {motor_id} velocity to {velocity} success: {response.success}")
        
        except Exception as e:
            self.node.get_logger().error(f"Failed to control motor {motor_id}: {str(e)}")
            
        return response    
    def SetCurrentAllHandCallback(self, request, response):
        response.success = False
        receive_data = 0
        
        if len(request.velocity) != 6:
            self.node.get_logger().error(f"array length incorrect, requires 6 elements, now : {len(request.velocity)}")
            return response
            
        for i, value in enumerate(request.velocity):
            if not (0 <= value <= 100):
                self.node.get_logger().error(f"the value of velocity[{i}] : {value} is out of range (0, 100)")
                return response

        velocity_list = [int(value) for value in request.velocity]
        
        try:
            receive_data = self.send_multiple_data(self.hand_id, zp.SetCurrentAllHandRegister, velocity_list)
            response.success = receive_data != 0
            self.node.get_logger().info(f"Set All Hand velocities success: {response.success}")

        except Exception as e:
            self.node.get_logger().error(f"Modbus通信失败: {str(e)}")

        return response

  

    def ClearErrorCallback(self, request, response):
        response.success = False
        receive_data = 0
        
        try:
            receive_data = self.send_single_data(self.hand_id, zp.ClearErrorRegister, 1)
            response.success = receive_data != 0
            self.node.get_logger().info(f"Clear Error success: {response.success}")
            
        except Exception as e:
            self.node.get_logger().error(f"Clear Error failed: {str(e)}")
            
        return response


    def RestoreFactorySettingsCallback(self, request, response):
        response.success = False
        receive_data = 0
        try:
            receive_data = self.send_single_data(self.hand_id, zp.RestoreFactorySettingsRegister, 1)
            response.success = receive_data != 0
            self.node.get_logger().info(f"Restore factory settings: {response.success}")
            
        except Exception as e:
            self.node.get_logger().error(f"Restore factory settings failed: {str(e)}")
            
        return response




    # def SaveConfigurationCallback(self, request, response):
    #     """
    #     -save configurations to flash
    #     -configurations:ID & Baudrate
    #     """
    #     response.success = False
        
    #     try:
    #         self.node.get_logger().info(f"Attempting to save configuration for ID: {self.hand_id}")
            
    #         self.node.get_logger().info("Starting full hand calibration...")
    #         receive_data = self.send_single_data(self.hand_id, 0x03, 1)
    #         response.success = receive_data != 0
    #         self.node.get_logger().info(f"Full hand calibration success: {response.success}")
    #     except Exception as e:
    #         self.node.get_logger().error(f"Failed to save configuration: {str(e)}")
            
    #     try:
    #         # 将当前ID写入配置文件
    #         zp_path = os.path.abspath(zp.__file__)
    #         self.node.get_logger().info(f"Writing configuration to file: {zp_path}")
            
    #         with open(zp_path, 'r', encoding='utf-8') as f:
    #             lines = f.readlines()
                
    #         updated = False
    #         for i in range(len(lines)):
    #             if lines[i].strip().startswith('hand_id ='):
    #                 lines[i] = f"hand_id = {self.hand_id}\n"
    #                 updated = True
    #                 break
            
                    
    #         if not updated:
    #             raise RuntimeError("Failed to find 'hand_id =' line in configuration file")
                
    #         with open(zp_path, 'w', encoding='utf-8') as f:
    #             f.writelines(lines)
                
    #         self.node.get_logger().info(f"Configuration saved permanently. Hand ID: {self.hand_id}")
    #         response.success = True
    #     except Exception as e:
    #         self.node.get_logger().error(f"Failed to write configuration files: {str(e)}")
    #     return response

    def SaveConfigurationCallback(self, request, response):
        """
        - 仅下发保存配置指令到设备（ID & Baudrate）
        - 不修改本地配置文件
        """
        response.success = False
        
        try:
            self.node.get_logger().info(f"Attempting to save configuration (ID: {self.hand_id}, Baudrate: {self.ser.baudrate}) to device")
            receive_data = self.send_single_data(self.hand_id, zp.SaveConfigurationRegister, 1)
            response.success = receive_data != 0
            self.node.get_logger().info(f"Configuration save command sent. Success: {response.success}")
        except Exception as e:
            self.node.get_logger().error(f"Failed to send configuration save command: {str(e)}")
        return response


    def StopEmergencyCallback(self, request, response):
        response.success = False
        receive_data = 0
        
        try:

            send_data_list = [1] * 6
            receive_data = self.send_multiple_data(self.hand_id, zp.StopEmergencyRegister, send_data_list)
            
            response.success = receive_data != 0
            self.node.get_logger().info(f"EMERGENCY STOP: {response.success}")
            
        except Exception as e:
            self.node.get_logger().error(f"Failed to emengency stop: {str(e)}")

        return response


    # --------------------------------------------------
    # Getter callback functions
    # --------------------------------------------------
    def GetInitializationSignalCallback(self, request, response):
        response.success = False
        response.initialization_signal = False

        try:
            receive_data = self.read_multiple_data(self.hand_id, zp.GetInitializationSignalRegister,1,1)
            response.success = receive_data != 0
            response.initialization_signal = (receive_data[1] == 1)
            self.node.get_logger().info(f"Get Initialization Signal:{response.initialization_signal}")

        except Exception as e:
            self.node.get_logger().error(f"Failed to get initialization signal: {str(e)}")
        return response
    
    def GetBootloaderVersionCallback(self, request, response):
        response.success = False
        response.bootloader_version = 65535

        try:
            receive_data = self.read_multiple_data(self.hand_id, zp.GetBootloaderVersionRegister,1,1)
            response.success = receive_data != 0
        
            # self.node.get_logger().info(f"receive_data:{receive_data}") # test

            response.bootloader_version = (receive_data[0] * 256 + receive_data[1])
            self.node.get_logger().info(f"Get bootloader version:{response.bootloader_version}")
        except Exception as e:
            self.node.get_logger().error(f"Failed to get bootloader version: {str(e)}")
        return response

    def GetHardwareVersionCallback(self, request, response):
        response.success = False
        response.hardware_version = 65535

        try:
            receive_data = self.read_multiple_data(self.hand_id, zp.GetHardwareVersionRegister,1,1)
            response.success = receive_data != 0

            # self.node.get_logger().info(f"receive_data:{receive_data}") # test

            response.hardware_version = (receive_data[0] * 256 + receive_data[1])
            self.node.get_logger().info(f"Get Hardware version:{response.hardware_version}")
        except Exception as e:
            self.node.get_logger().error(f"Failed to get Hardware version: {str(e)}")
        return response

    def GetSoftwareVersionCallback(self, request, response):
        response.success = False
        response.software_version = 65535

        try:
            receive_data = self.read_multiple_data(self.hand_id, zp.GetSoftwareVersionRegister,1,1)
            response.success = receive_data != 0

            # self.node.get_logger().info(f"receive_data:{receive_data}") # test

            response.software_version = (receive_data[0] * 256 + receive_data[1])
            self.node.get_logger().info(f"Get Software version:{response.software_version}")
        except Exception as e:
            self.node.get_logger().error(f"Failed to get Software version: {str(e)}")
        return response

    def GetHallErrorCallback(self, request, response):
        # 1-Error   0-NoError
        response.success = False
        hall_errors = [0] * 6
        try:
            receive_data = self.read_multiple_data(self.hand_id, zp.GetHallErrorRegister,6,1)
            response.success = receive_data != 0

            for i in range(0,6):
                hall_errors[i] = receive_data[2 * i + 1]

            response.hall_error = hall_errors
            self.node.get_logger().info(f"Get hall errors:{response.hall_error}")
        except Exception as e:
            self.node.get_logger().error(f"Failed to get hall errors: {str(e)}")
        return response
    

    def GetDeviceVoltageCallback(self, request, response):
        response.success = False
        response.voltage = 65535
        

        try:
            receive_data = self.read_multiple_data(self.hand_id, zp.GetVoltageAddressRegister,1,0)
            response.success = receive_data != 0

            self.node.get_logger().info(f"receive_data:{receive_data}") # test

            response.voltage = (receive_data[0] * 256 + receive_data[1])
            self.node.get_logger().info(f"Get device voltage:{response.voltage}")
        except Exception as e:
            self.node.get_logger().error(f"Failed to get device voltage: {str(e)}")
        return response
    
    def GetFullScalePositionCallback(self, request, response):
        # 1-Error   0-NoError
        response.success = False
        full_scale_positions = [0] * 6
        try:
            receive_data = self.read_multiple_data(self.hand_id, zp.GetFullScalePositionRegister,6,1)
            
            response.success = receive_data != 0

            for i in range(0,6):
                # full_scale_positions[i] = receive_data[2 * i + 1]
                full_scale_positions[i] = 256 * receive_data[2 * i] + receive_data[2 * i + 1]

            response.full_scale_positions = full_scale_positions
            self.node.get_logger().info(f"Get full scale positions:{response.full_scale_positions}")
        except Exception as e:
            self.node.get_logger().error(f"Failed to get full scale positions: {str(e)}")
        return response
    
    def GetMotorRpmCallback(self, request, response):
        # 1-Error   0-NoError
        response.success = False
        motor_rpm = [0] * 6
        try:
            receive_data = self.read_multiple_data(self.hand_id, zp.GetMotorRpmRegister,6,1)
            response.success = receive_data != 0

            for i in range(0,6):
                motor_rpm[i] = receive_data[2 * i] + receive_data[2 * i + 1]

            response.motor_rpm = motor_rpm
            self.node.get_logger().info(f"Get motor rpm:{response.motor_rpm}")
        except Exception as e:
            self.node.get_logger().error(f"Failed to get motor rpm: {str(e)}")
        return response
    
    def GetMotorCurrentCallback(self, request, response):
        # 1-Error   0-NoError
        response.success = False
        motor_current = [0] * 6
        try:
            receive_data = self.read_multiple_data(self.hand_id, zp.GetMotorCurrentRegister,6,1)
            response.success = receive_data != 0

            for i in range(0,6):
                motor_current[i] = receive_data[2 * i] + receive_data[2 * i + 1]

            response.motor_current = motor_current
            self.node.get_logger().info(f"Get motor current:{response.motor_current}")
        except Exception as e:
            self.node.get_logger().error(f"Failed to get motor current: {str(e)}")
        return response
    
    def GetPhaseLossFaultCallback(self, request, response):
        # 1-Error   0-NoError
        response.success = False
        phase_loss_error = [0] * 6
        try:
            receive_data = self.read_multiple_data(self.hand_id, zp.GetPhaseLossFaultRegister,6,1)
            response.success = receive_data != 0

            for i in range(0,6):
                phase_loss_error[i] = receive_data[2 * i] + receive_data[2 * i + 1]

            response.phase_loss_error = phase_loss_error
            self.node.get_logger().info(f"Get phase loss error:{response.phase_loss_error}")
        except Exception as e:
            self.node.get_logger().error(f"Failed to get phase loss error: {str(e)}")
        return response
    
    def GetCurrentSampleErrorCallback(self, request, response):
        # 1-Error   0-NoError
        response.success = False
        current_sample_error = [0] * 6
        try:
            receive_data = self.read_multiple_data(self.hand_id, zp.GetCurrentSampleErrorRegister,6,1)
            response.success = receive_data != 0

            for i in range(0,6):
                current_sample_error[i] = receive_data[2 * i] + receive_data[2 * i + 1]

            response.hall_error = current_sample_error
            self.node.get_logger().info(f"Get current sample error:{response.current_sample_error}")
        except Exception as e:
            self.node.get_logger().error(f"Failed to get current sample error: {str(e)}")
        return response

    def GetRealtimeAngleCallback(self, request, response):
        # 1-Error   0-NoError
        response.success = False
        realtime_angles = [0] * 6
        try:
            receive_data = self.read_multiple_data(self.hand_id, zp.ReadRealtimeAngles,6,1)
            response.success = receive_data != 0

            for i in range(0,6):
                realtime_angles[i] = receive_data[2 * i] + receive_data[2 * i + 1]

            response.realtime_angles = realtime_angles
            self.node.get_logger().info(f"Get realtime angles:{response.realtime_angles}")
        except Exception as e:
            self.node.get_logger().error(f"Failed to get realtime angles: {str(e)}")
        return response
    
    def GetRealTimeMotorStallCallback(self, request, response):
        # 1-Error   0-NoError
        response.success = False
        realtime_motor_stall = [0] * 6
        try:
            receive_data = self.read_multiple_data(self.hand_id, zp.ReadRealtimeMotorStall,6,1)
            response.success = receive_data != 0

            for i in range(0,6):
                realtime_motor_stall[i] = receive_data[2 * i] + receive_data[2 * i + 1]

            response.realtime_motor_stall = realtime_motor_stall
            self.node.get_logger().info(f"Get realtime motor stall:{response.realtime_motor_stall}")
        except Exception as e:
            self.node.get_logger().error(f"Failed to get realtime motor stall: {str(e)}")
        return response
    
    
    
    # --------------------------------------------------
    # topic communication
    # --------------------------------------------------
    def read_realtime_angles(self):
        realtime_angles = [0] * 6
        try:
            receive_data = self.read_multiple_data(self.hand_id, zp.ReadRealtimeAngles,6,1)
            if receive_data != 0:
                if len(receive_data) == 12:
                    for i in range(6):
                        realtime_angles[i] = (receive_data[2 * i] << 8) + receive_data[2 * i + 1]
                # self.node.get_logger().info(f"realtime_angles: {realtime_angles}")
            else:
                self.node.get_logger().error(f"Failed to read realtime angles")
            return realtime_angles

        except Exception as e:
            self.node.get_logger().error(f"Failed to read realtime angles: {str(e)}")
            return []


    def read_realtime_motor_stall(self):
        realtime_motor_stall = [0] * 6
        try:
            receive_data = self.read_multiple_data(self.hand_id, zp.ReadRealtimeMotorStall,6,1)

            if receive_data != 0:
                if len(receive_data) == 12:
                    for i in range(6):
                        realtime_motor_stall[i] = (receive_data[2 * i] << 8) + receive_data[2 * i + 1]
                # self.node.get_logger().info(f"realtime_motor_stall: {realtime_motor_stall}")

            else:
                self.node.get_logger().error(f"Failed to read realtime angles")

            
            

            return realtime_motor_stall

        except Exception as e:
            self.node.get_logger().error(f"Failed to read realtime angles: {str(e)}")
            return []
    # --------------------------------------------------
    # 关闭串口
    # --------------------------------------------------
    def close(self):
        if self.ser and self.ser.is_open:
            self.ser.close()