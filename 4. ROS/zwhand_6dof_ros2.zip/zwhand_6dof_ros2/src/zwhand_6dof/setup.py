from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'zwhand_6dof'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # 安装launch文件
                (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools', 'interface', 'rclpy'],
    zip_safe=True,
    maintainer='liang',
    maintainer_email='liang@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'hand_control = zwhand_6dof.hand_control:main',  # 添加可执行文件入口
            'motor_stall_subscriber = zwhand_6dof.motor_stall_subscriber:main',  # 新增订阅者节点入口
            'angle_subscriber = zwhand_6dof.angle_subscriber:main',  # 新增订阅者节点入口
        ],
    },
)
