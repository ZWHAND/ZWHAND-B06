#!/bin/bash

# 直接在当前终端执行，不使用tmux
echo "启动ROS2手部控制程序..."

# 加载环境（请确认路径正确）
source ~/zwhand_6dof/install/setup.bash
sleep 1

# 定义发送命令的函数
send_angle_command() {
    local angle_index=$1
    local angle_value=$2
    
    angles=(0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0)
    angles[$angle_index]=$angle_value
    
    angles_str="["
    for ((j=0; j<17; j++)); do
        angles_str+="${angles[j]}"
        if ((j < 16)); then
            angles_str+=", "
        fi
    done
    angles_str+="]"
    
    # 直接在当前终端执行命令
    echo "发送命令: 关节 $angle_index 角度 $angle_value"
    ros2 service call /zwhand_6dof/control_all_hand interface/srv/ControlAllHand "{angles: $angles_str}"
    sleep 1
}

# 无限循环
while true; do
    for ((joint=0; joint<17; joint++)); do
        echo "控制关节 $joint:"
        send_angle_command $joint 0
        send_angle_command $joint 1000
        send_angle_command $joint 0
    done
    
    echo "完成一轮循环，2秒后开始下一轮"
    sleep 2
done
